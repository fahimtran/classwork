@FunctionalInterface
public interface InterfaceTwo {
    // add two ints
    int add(int a, int b);
}
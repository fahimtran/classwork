// class that implements Interface
public class Implemented implements Interface {
    public void print(Object obj) {
        System.out.println(obj);
    }
}
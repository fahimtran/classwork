package pkg1.pkg10.pkg2018;

/**
 *
 * @author Fahim Jeylani-Tran
 */

//CIST 2372 Java Programming II, In-Class Assignment

/*
    a) Display the value of element 9 of array 'fractions'
    b) Declare an array arr with five elements of type double and initialize it with the elements - 3.4, 7.8, 6.9, 8.5, 9.1
    c) Find the sum of 10 elements of int array 'b' using enhanced for statement
*/
public class Main {

    public static void main(String[] args) {
        
        //----QUESTION A----
        //For Question A, Displaying the value of element 9 of array 'fractions' require an array declared called fractions (doesn't specify type).
        int[] fractions = new int[9];
        
        //Displaying element 9 of array 'fractions' would require use to use the Array-Access Expression with indices which is the element number minus 1.
        System.out.println("Element 9 of Array 'fractions':");
        System.out.println(fractions[8]);
        System.out.println();
        
        //----QUESTION B----
        //Initialization of the double array 'arr' uses the initialization block for arrays.
        double[] arr = {3.4, 7.8, 6.9, 8.5, 9.1};
        
        //Displaying all the elements in the array called 'arr'
        System.out.println("Arr elements:");
        for(double number: arr){
            System.out.println(number);
        }
        System.out.println();
        
        //----QUESTION C----
        //Finding the sum of int array 'b' requires a variable to hold the sum and an array declared/initialized called 'b'
        int[] b = new int[10];
        b[0] = 54;
        double sum = 0;
        
        //Here's the enhanced for-loop calculating the sum of 10 elements in array 'b', which should be 54.
        for(int number: b){
            sum += number;
        }
        
        //Displaying the sum calculated by the enhanced for-loops
        System.out.println("Sum of all the elements in Array 'b':");
        System.out.println(sum);
    }
    
}

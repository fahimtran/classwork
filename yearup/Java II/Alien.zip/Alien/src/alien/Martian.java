package alien;

/**
 *
 * @author Fahim Jeylani-Tran
 */
public class Martian extends Alien{
    
    public Martian(){
        super(3, 21, "Iron Red");
    }
    
}

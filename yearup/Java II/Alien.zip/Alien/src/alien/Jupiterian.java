package alien;

/**
 *
 * @author Fahim Jeylani-Tran
 */
public class Jupiterian extends Alien{
    
    public Jupiterian(){
        super(6, 2, "Doo-Doo Brown");
    }
    
}

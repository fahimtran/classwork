package alien;

/**
 *
 * @author Fahim Jeylani-Tran
 */
public class CreateAliens {
    
    public static void main(String[] args){
        Martian jimmy = new Martian();
        Jupiterian jonny = new Jupiterian();
        
        System.out.println(jimmy);
        System.out.println(jonny);
    }
    
}

package alien;

/**
 *
 * @author Fahim Jeylani-Tran
 */
public class Alien {

    protected int eyes;
    protected int fingers;
    protected String color;

    public Alien(int x, int y, String z){
        eyes = x;
        fingers = y;
        color = z;
    }
    
    public String toString(){
        return "This alien has " + eyes + " eyes, " + fingers + " fingers, and "
                + "is the color " + color + ".";
    }
}

package intstreamfilteringandsorting;

/**
 *
 * @author Fahim
 */

//Exercise 17.16
import java.security.SecureRandom;

public class IntStreamFilteringAndSorting {

    public static void main(String[] args) {
        //Very simple problem using lambdas
        //Randomization using requested method
        SecureRandom random = new SecureRandom();
        random.ints(50, 1, 1000)
                //Filter out the odd numbers
                .filter(x -> x % 2 == 1)
                //Sort the stream in order
                .sorted()
                //Then print the stream in the order it's in
                .forEach(System.out::println);
    }
    
}

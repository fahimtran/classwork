import javax.swing.JOptionPane;
public class CommentsDialog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Program comments are nonexecuting statements you add to a file for the purpose of documentation.");
		/* Did you know my cousin is a nerd? */
		/** Did you also know that my cousin is a big fat loser? */
	}

}

import javax.swing.JOptionPane;
public class BurmaShave {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Shaving brushes");
		JOptionPane.showMessageDialog(null, "You'll soon see 'em");
		JOptionPane.showMessageDialog(null, "On a shelf");
		JOptionPane.showMessageDialog(null, "In some museum");
		JOptionPane.showMessageDialog(null, "Burma Shave");
	}

}


public class FavoriteSong {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("I awake to find no peace of mind\r\n" + 
				"I said, \"How do you live as a fugitive\r\n" + 
				"Down here where I cannot see so clear?\"\r\n" + 
				"I said, \"What do I know");
	}

}


public class SammysMotto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Sammy's makes it fun in the sun");
	}

}

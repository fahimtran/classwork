
public class PersonalInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Fahim Jeylani-Tran");
		System.out.println("exfahim@gmail.com");
		System.out.println("678-836-6894");
	}

}

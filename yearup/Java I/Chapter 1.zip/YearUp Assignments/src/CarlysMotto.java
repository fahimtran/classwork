
public class CarlysMotto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Carly's makes the food that makes it a party.");
	}

}

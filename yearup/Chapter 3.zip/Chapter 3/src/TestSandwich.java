
public class TestSandwich {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sandwich tuna = new Sandwich();
		tuna.setBread("White");
		tuna.setIngredient("Mayo");
		tuna.setPrice(4.88);
	}

}

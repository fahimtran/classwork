
public class MyCharacter {
	private int height;
	private int weight;
	private int strength;
	public void setHeight(int x) {
		height = x;
	}
	public int getHeight() {
		return height;
	}	
	public void setWeight(int x) {
		weight = x;
	}
	public int getWeight() {
		return weight;
	}	
	public void setStrength(int x) {
		strength = x;
	}
	public int getStrength() {
		return strength;
	}
}

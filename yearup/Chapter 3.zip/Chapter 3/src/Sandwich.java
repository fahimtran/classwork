
public class Sandwich {
	private String ingredient;
	private String bread;
	private double price;
	
	public void setPrice(double pr) {
		price = pr;
	}
	public double getPrice() {
		return price;
	}
	public void setIngredient(String ing) {
		ingredient = ing;
	}
	public String getIngredient() {
		return ingredient;
	}
	public void setBread(String br) {
		bread = br;
	}
	public String getBread() {
		return bread;
	}
}

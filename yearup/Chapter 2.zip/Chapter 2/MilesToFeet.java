
public class MilesToFeet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int FEETS_IN_MILE = 5280;
		int distanceMiles = 8;
		int distanceFeet = distanceMiles * FEETS_IN_MILE;
		System.out.println("The distance to my uncle's house is " + distanceMiles + " miles or " + distanceFeet + " feet.");
	}

}


public class InchesToFeet {
	public static void main(String[] args) {
		int inches = 32;
		final int INCHES_IN_FEET = 12;
		System.out.println( (inches/INCHES_IN_FEET)+ " feet and " + (inches % INCHES_IN_FEET) + " inches.");
	}
}

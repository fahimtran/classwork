
public class Initials {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char first = 'F', middle = 'F', last = 'J';
		System.out.println(first + "." + middle + "." + last);
	}

}

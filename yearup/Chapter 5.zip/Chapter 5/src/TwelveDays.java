import java.util.Scanner;
public class TwelveDays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int day = 0;
		System.out.println("What day do you want to start on? ");
		day = input.nextInt();
		switch(day) {
		case 1:
			System.out.println("On the first day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"A Partridge in a Pear Tree\r\n");
		case 2:
			System.out.println("On the second day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"Two Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 3:
			System.out.println("On the third day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"Three French Hens\r\n" + 
					"Two Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 4:
			System.out.println("On the fourth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"Four Calling Birds\r\n" + 
					"Three French Hens\r\n" + 
					"Two Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 5:
			System.out.println("On the fifth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 6:
			System.out.println("On the sixth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 7:
			System.out.println("On the seventh day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"7 Swans a Swimming\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 8:
			System.out.println("On the eighth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"8 Maids a Milking\r\n" + 
					"7 Swans a Swimming\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 9:
			System.out.println("On the ninth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"9 Ladies Dancing\r\n" + 
					"8 Maids a Milking\r\n" + 
					"7 Swans a Swimming\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 10:
			System.out.println("On the tenth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"10 Lords a Leaping\r\n" + 
					"9 Ladies Dancing\r\n" + 
					"8 Maids a Milking\r\n" + 
					"7 Swans a Swimming\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 11:
			System.out.println("On the eleventh day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"11 Pipers Piping\r\n" + 
					"10 Lords a Leaping\r\n" + 
					"9 Ladies Dancing\r\n" + 
					"8 Maids a Milking\r\n" + 
					"7 Swans a Swimming\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree\r\n");
		case 12:
			System.out.println("On the twelfth day of Christmas\r\n" + 
					"my true love sent to me:\r\n" + 
					"12 Drummers Drumming\r\n" + 
					"11 Pipers Piping\r\n" + 
					"10 Lords a Leaping\r\n" + 
					"9 Ladies Dancing\r\n" + 
					"8 Maids a Milking\r\n" + 
					"7 Swans a Swimming\r\n" + 
					"6 Geese a Laying\r\n" + 
					"5 Golden Rings\r\n" + 
					"4 Calling Birds\r\n" + 
					"3 French Hens\r\n" + 
					"2 Turtle Doves\r\n" + 
					"and a Partridge in a Pear Tree");

		}
	}

}

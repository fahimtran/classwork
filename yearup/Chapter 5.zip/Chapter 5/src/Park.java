
public class Park {
	
	private String name;
	private int acres;
	private boolean picnic, tennis, playground, pool;
	
	public String getName() {
		return name;
	}
	public void setName(String nm) {
		name = nm;
	}
	public int getAcres() {
		return acres;
	}
	public void setAcres(int ac) {
		acres = ac;
	}
	public boolean getPicnic() {
		return picnic;
	}
	public void setPicnic(boolean pic) {
		picnic = pic;
	}
	public boolean getTennis() {
		return tennis;
	}
	public void setTennis(boolean ten) {
		tennis = ten;
	}
	public boolean getPlay() {
		return playground;
	}
	public void setPlay(boolean pg) {
		playground = pg;
	}
	public boolean getPool() {
		return pool;
	}
	public void setPool(boolean pool) {
		this.pool = pool;
	}
	
}

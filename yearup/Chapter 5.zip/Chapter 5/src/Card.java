
public class Card {
	private char suit;
	private int number;
	
	public void setSuit(char x) {
		suit = x;
	}
	public char getSuit() {
		return suit;
	}
	public void setNumber(int x) {
		number = x;
	}
	public int getNumber() {
		return number;
	}
}

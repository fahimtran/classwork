package Chapter4;
import java.time.*;
public class TestWedding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate time1 = LocalDate.now();
		
		Person john = new Person("John", "Creek", time1);
		Person sally = new Person("Sally", "Sue", time1);
		
		Couple dating = new Couple(john, sally);
		Couple dating2 = new Couple(sally, john);
		
		Wedding one = new Wedding("Bryan Park", dating);
		Wedding two = new Wedding("Yellow Stone", dating2);
		
		display(one);
		display(two);
	}
	public static void display(Wedding x) {
		System.out.println("Here's this wedding at " + x.getLocation() + ", with the couple that has the names " + x.getCouple().getPersonOne().getFirst() 
				+ " " + x.getCouple().getPersonOne().getLast() + " and " + x.getCouple().getPersonTwo().getFirst() + " " + x.getCouple().getPersonTwo().getLast()
				+ ".");
	}
}

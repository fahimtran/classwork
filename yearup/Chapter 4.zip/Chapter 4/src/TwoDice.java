
public class TwoDice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Die one = new Die();
		Die two = new Die();
		
		System.out.println("Die One: " + one.getRandomValue() + "\nDie Two: " + two.getRandomValue());
	}

}


public class TestBirdSighting2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BirdSighting2 birb = new BirdSighting2();
		birb.getBirdSpecies();
		birb.getDayOfTheYear();
		birb.getNumberSeen();
	}

}

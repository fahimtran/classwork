
public class MathTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(Math.sqrt(37));
		System.out.println(Math.sin(300) + " " + Math.cos(300));
		System.out.println(Math.floor(22.8) + " " + Math.ceil(22.8) + " " + Math.round(22.8));
		System.out.println(Math.max(0, 71) + " " + Math.min(0, 71));
		System.out.println(Math.random() * 20);
 	}

}


public class TestState {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		State georgia = new State("Georgia", 7000000, "Atlanta", 1000000, "Savannah", 1000001);
		State georgia2 = new State("Georgia2", 7000000, "Atlanta2", 1000000, "Savannah2", 1000001);
		
		georgia.displayStateInfo();
		georgia2.displayStateInfo();
	}

}

package finalexamproject;

/**
 * @author Fahim
 */

/*
    Imports for Creating Files, Receiving User Input, Creating Output Streams, 
    and other necessary imports to write to a Random Access File.
*/
import java.nio.file.*;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import static java.nio.file.StandardOpenOption.*;
import static java.nio.file.AccessMode.*;
import java.util.Scanner;
import java.text.*;

/*
    This application will allow you to input multiple records containing 
    an ID number, a first name, a last name, and a balance.
*/
public class WriteCustomerList {
    public static void main(String[] args) {
        //Scanner object for receiving user input.
        Scanner input = new Scanner(System.in);
        
        //Creating a Path object which contains a path to the CustomerList.txt on the Desktop of the user.
        Path customerListPath = getUser(input);
        
        //Creating the format for a default record of customers.
        //Allows up to 20 characters for the first and last name.
        final String ID_FORMAT = "000";
        final String NAME_FORMAT = "                     ";
        final int NAME_LENGTH = NAME_FORMAT.length();
        final String BALANCE_FORMAT = "00000.00";
        String delimiter = ",";
        
        //The name format is being used twice for both the first and last name.
        String defaultRecord = ID_FORMAT + delimiter + NAME_FORMAT + delimiter 
                + NAME_FORMAT + delimiter + BALANCE_FORMAT 
                + System.getProperty("line.separator");
        final int RECORD_SIZE = defaultRecord.length();
        
        //Calls a method to create the CustomerList.txt file with 5 default records only if the file doesn't allow access to write.
        try{
            customerListPath.getFileSystem().provider().checkAccess(customerListPath, AccessMode.WRITE, AccessMode.READ);
            System.out.println("\nCustomerList.txt is available to be written to on the Desktop.");
        } catch(IOException e){
            createDefaultFile(customerListPath, defaultRecord);
        }
        
        //Calls a method to allow user write records to CustomerList.txt. Passes all formatting variables through this method.
        writeRecords(customerListPath, input, NAME_FORMAT, NAME_LENGTH, BALANCE_FORMAT, delimiter, RECORD_SIZE);
        
        //Displays the end of the program/application.
        System.out.println("End of program.");
    }
    
    //A method to establish a Path to the Desktop of the user.
    public static Path getUser(Scanner input){
        //Prompting user for user's computer account to create a path to the Desktop.
        System.out.println("Enter your current user account "
                + "(include capitalization/punctuation): ");
        String user = input.nextLine();
        return Paths.get("C:\\Users\\" + user + "\\Desktop\\CustomerList.txt");
    }
    
    //A method to create a .txt file containing 5 default records.
    public static void createDefaultFile(Path customerListPath, String defaultRecord){
        //Constant declarization and initialization for number of records.
        final int NUMBER_OF_RECORDS = 5;
        
        //Exception Handling to handle any IO Exceptions.
        try{
            //Creates the CustomerList.txt file and the writer to write default records.
            OutputStream outputStream = new
                BufferedOutputStream(Files.newOutputStream(customerListPath, CREATE));
            BufferedWriter writer = new
                BufferedWriter(new OutputStreamWriter(outputStream));
            
            //Creating default records by looping up to the declared number of records.
            for(int count = 0; count < NUMBER_OF_RECORDS; ++count)
                writer.write(defaultRecord);
            
            //Closes the Output Stream since the default writing has been finished.
            writer.close();
        } catch(IOException e){
            System.out.println("IO Exception. Error Message: " + e.getMessage());
        }
        //Confirmation that the default file has been created.
        System.out.println("\nCustomerList.txt created on Desktop.");
    }
    
    //Allows the user to write records to CustomerList.txt using a Scanner object.
    public static void writeRecords(Path customerListPath, Scanner input, String NAME_FORMAT,
            int NAME_LENGTH, String BALANCE_FORMAT, String delimiter, int RECORD_SIZE){
        //Declaration of variables to receive user input.
        String idString, firstName, lastName, record;
        int id;
        double balance;
        
        //Sentinel value used to break out of receiving records.
        final String QUIT = "999";
        
        //Exception Handling to handle IO Exceptions.
        try{
            //Creates a FileChannel to CustomerList.txt and establishes writing capabilities.
            FileChannel fc = (FileChannel)Files.newByteChannel(customerListPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            
            //Priming Read for Customer ID number for looping through writing records.
            System.out.println("\nEnter a Customer ID number >> ");
            idString = input.nextLine();
            
            //Allows writing of records as long as user doesn't enter sentinel value or nothing.
            while(!idString.equals(QUIT)){
                //Prompts user for first name, then fills in space to fit formatting.
                System.out.println("Enter the first name for Customer ID " + idString + " >> ");
                firstName = input.nextLine();
                StringBuilder sb = new StringBuilder(firstName);
                sb.setLength(NAME_LENGTH);
                firstName = sb.toString();
                
                //Prompts user for last name, then fills in space to fit formatting.
                System.out.println("Enter the last name for Customer ID " + idString + " >> ");
                lastName = input.nextLine();
                sb = new StringBuilder(lastName);
                sb.setLength(NAME_LENGTH);
                lastName = sb.toString();
                
                //Prompts user for balance.
                balance = balanceValidation(input, idString);
                
                //Sets formatting for balances.
                DecimalFormat df = new DecimalFormat(BALANCE_FORMAT);
                
                //Strings together all of the information including formatting, separated by delimiters to make a record.
                record = idString + delimiter + firstName + delimiter + lastName 
                        + delimiter + df.format(balance) 
                        + System.getProperty("line.separator");
                
                //Converts the record into an array of bytes for use by ByteBuffer.
                byte data[] = record.getBytes();
                ByteBuffer buffer = ByteBuffer.wrap(data);
                
                //Parses idString to an Integer to position record.
                id = Integer.parseInt(idString);
                fc.position(id * RECORD_SIZE);
                
                //Writes record to position.
                fc.write(buffer);
                
                //Catches an Enter-key buffer.
                input.nextLine();
                
                //Reprompts for next iteration.
                System.out.println("\nEnter next Customer ID or type " + QUIT + " to exit. >> ");
                idString = input.nextLine();
            }
            
            //Closes FileChannel object.
            fc.close();
        } catch(IOException e){
            System.out.println("IO Exception. Error Message: " + e.getMessage());
        }
    }
    
    //Method to make sure user enters a double for balances.
    public static double balanceValidation(Scanner input, String idString){
        double balance = 0;
        while (true) {
            try {
                System.out.println("Enter the balance for Customer ID " + idString + " >> ");
                balance = Double.parseDouble(input.next());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
            }
        }
        return balance;
    }
}

package finalexamproject;

/**
 * @author Fahim
 */

//Imports to allow application to display CustomerList.txt.
import java.nio.file.*;
import java.io.*;
import java.util.Scanner;

public class DisplaySavedCustomerList {
    public static void main(String[] args) {
        //Creates a Scanner object that receives input from the user's keyboard.
        Scanner keyboard = new Scanner(System.in);
        
        //Calls getUser(Scanner input) written in WriteCustomerList.java so that I don't have to rewrite it.
        Path file = WriteCustomerList.getUser(keyboard);
        
        //Declares record for use of holding a record from a file then displaying it.
        String record = "";
        
        //Formatting so that user knows what is being displayed.
        System.out.println("\nSaved Customer List:");
        System.out.println("----------------------------------------------------------------------------------");
        System.out.println("ID#     First Name              Last Name                   Balance");
        System.out.println("----------------------------------------------------------------------------------");
        
        //Exception handling to handle any IO Exceptions.
        try {
            //Creating a new input stream along with a reader to read from that input stream.
            InputStream input = new BufferedInputStream(Files.newInputStream(file));
            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            
            //Priming read for the while loop that follows.
            record = reader.readLine();
            
            //While loop that will read and print records one by one until there are no more left.
            while (record != null) {
                System.out.println(record);
                record = reader.readLine();
            }
            //End formatting to show the user where the list ends.
            System.out.println("----------------------------------------------------------------------------------");
            reader.close();
        } catch (IOException e) {
            System.out.println("Error Message: " + e);
        }
        
        //Declaration of the end of the program.
        System.out.println("End of program.");
    }
}

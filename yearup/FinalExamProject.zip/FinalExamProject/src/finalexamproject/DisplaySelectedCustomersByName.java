package finalexamproject;

/**
 * @author Fahim
 */

//Necessary imports for selecting specific records by last name;
import java.io.*;
import java.nio.file.*;
import java.util.Scanner;

public class DisplaySelectedCustomersByName {
    public static void main(String[] args){
        //Creation of a Scanner object to receive user input.
        Scanner keyboard = new Scanner(System.in);
        
        //Path object to locate the CustomerList.txt on the Desktop of the user.
        Path file = WriteCustomerList.getUser(keyboard);
        
        //Declaration of formatting to find the record size of all records.
        final String ID_FORMAT = "000";
        final String NAME_FORMAT = "                     ";
        final String BALANCE_FORMAT = "00000.00";
        String delimiter = ",";
        String record = ID_FORMAT + delimiter + NAME_FORMAT + delimiter 
                + NAME_FORMAT + delimiter + BALANCE_FORMAT 
                + System.getProperty("line.separator");
        
        //Prepping a buffer for the default record using an array of bytes.
        String[] array = new String[4];
        
        //Prompting user for name that user is looking for.
        System.out.println("\nEnter the last name that you are looking for: ");
        String lastName = keyboard.nextLine();
        
        //Formatting for readability.
        System.out.println("\nList of Customers with the last name " + lastName + ".");
        System.out.println("----------------------------------------------------------------------------------");
        
        //Exception handling for IO Exceptions.
        try{
            //Using an input stream from the CustomerList.txt and a reader to read each line.
            InputStream inputStream = new
                BufferedInputStream(Files.newInputStream(file));
            BufferedReader reader = new
                BufferedReader(new InputStreamReader(inputStream));
            
            //A count to determine if there are any names by the user's request.
            int count = 0;
            
            //A loop to loop through each record and check if for records that have the requested last name.
            while(record != null){
                array = record.split(delimiter);
                if(array[2].trim().toLowerCase().equals(lastName.trim().toLowerCase())){
                    ++count;
                    System.out.println("Customer ID #" + array[0] + delimiter 
                            + array[1] + delimiter + array[2] + delimiter + array[3]);
                }
                record = reader.readLine();
            }
            if(count == 0){
                System.out.println("No Customers are available with the last name " + lastName);
            }
            //End formatting.
            System.out.println("----------------------------------------------------------------------------------");
            
        } catch(IOException e){
            System.out.println("IO Exception. File can't be found. Error Message: " + e.getMessage());
        }
        //Declaration of the end of the program.
        System.out.println("\nEnd of program.");
    }
}

package finalexamproject;

/**
 * @author Fahim
 */

//Imports to allow user to pinpoint location of an ID using a Random Acces File.
import java.nio.file.*;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.ByteBuffer;
import static java.nio.file.StandardOpenOption.*;
import java.util.Scanner;

public class DisplaySelectedCustomer {

    public static void main(String[] args) {
        //Creation of a Scanner object to receive user input.
        Scanner keyboard = new Scanner(System.in);
        
        //Path Object created by calling WriteCustomerList.getUser(Scanner input).
        Path file = WriteCustomerList.getUser(keyboard);
        
        //Initialization of a default record to get the record size for positioning in the FileChannel.
        //Copied from WriteCustomerList.java to reduce errors.
        final String ID_FORMAT = "000";
        final String NAME_FORMAT = "                     ";
        final String BALANCE_FORMAT = "00000.00";
        String delimiter = ",";
        String record = ID_FORMAT + delimiter + NAME_FORMAT + delimiter 
                + NAME_FORMAT + delimiter + BALANCE_FORMAT 
                + System.getProperty("line.separator");
        final int RECORD_SIZE = record.length();
        
        //Sets up an array of bytes to receive records. Initialized to a default record form of bytes.
        byte[] data = record.getBytes();
        ByteBuffer buffer;
        
        //Variables to receive user input and locate records in CustomerList.txt.
        String idString;
        int id;
        
        final String QUIT = "999";
        
        //Exception Handling to handle IO Exceptions.
        try {
            //Creation of a file channel to read records.
            FileChannel fc = (FileChannel)Files.newByteChannel(file, READ);
            
            //Priming read for the while loop that follows.
            System.out.print("\nEnter a Customer ID number or " + QUIT + " to quit >> ");
            idString = keyboard.nextLine();
            
            //While loop to loop through the records by ID until user enters sentinel value.
            while (!idString.equals(QUIT)) {
                //Wraps the array of bytes of the default record into a buffer.
                buffer = ByteBuffer.wrap(data);
                
                //Parses the idString to locate the record location.
                id = Integer.parseInt(idString);
                
                //Positions the FileChannel at the correct record.
                fc.position(id * RECORD_SIZE);
                
                //Inputs a record from the position the FileChannel is currently located.
                fc.read(buffer);
                
                //Converts the buffer into a String which can be printed.
                record = new String(data);
                System.out.println("Customer ID #" + id + " " + record);
                
                //Reprompt of the user to enter a Customer ID.
                System.out.print("Enter a Customer ID number or " + QUIT + " to quit >> ");
                idString = keyboard.nextLine();
            }
            //Closes FileChannel.
            fc.close();
        } catch (IOException e) {
            System.out.println("IO Exception. Error message: " + e);
        }
        //Declaration of the end of program.
        System.out.println("End of program.");
    }
}
